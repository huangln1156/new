# network_monitor_demo
Android 网络状态监控框架
文档说明：https://www.jianshu.com/p/86d347b2a12b
