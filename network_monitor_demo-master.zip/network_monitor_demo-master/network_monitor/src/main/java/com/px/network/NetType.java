package com.px.network;

public enum NetType {
    AUTO,//全部状态
    NONE,//无网络
    WIFI,
    MOBILE
}
