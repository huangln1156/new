package com.example.administrator.android003.Utils;

/**
 * Created by Administrator on 2016/5/12.
 */
public class RequestCodeInfo {

	public static final int GETCITY=0x000001;

}
