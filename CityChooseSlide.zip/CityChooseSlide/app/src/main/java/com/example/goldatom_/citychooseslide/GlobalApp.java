package com.example.goldatom_.citychooseslide;

import android.app.Activity;
import android.app.Application;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Vibrator;
import com.baidu.mapapi.SDKInitializer;
public class GlobalApp extends Application {
    public static LocationUtils mLocationUtils = null;
    private static GlobalApp mInstance = null;
	public void onCreate() {
		super.onCreate();
        mInstance=this;
		AssertsFileUtils.getCityAll(this);
		SDKInitializer.initialize(getApplicationContext());// 初始化百度地图
		Vibrator vibrator = (Vibrator) this.getSystemService(VIBRATOR_SERVICE);// 获取震动类
		mLocationUtils = LocationUtils.getInstance(getApplicationContext(),
				vibrator);// 初始化百度地图工具类
		mLocationUtils.getLcation(null, null, 2000, true);// 初始化百度地图定位设置
		mLocationUtils.startLocation();// 启动定位

	}

    public static GlobalApp getmInstance() {
        return mInstance;
    }

    public static void setmInstance(GlobalApp mInstance) {
        GlobalApp.mInstance = mInstance;
    }
}
