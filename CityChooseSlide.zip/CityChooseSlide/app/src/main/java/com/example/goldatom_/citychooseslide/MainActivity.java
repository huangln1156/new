package com.example.goldatom_.citychooseslide;

import android.content.Intent;
import android.os.Vibrator;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.baidu.mapapi.SDKInitializer;

public class MainActivity extends AppCompatActivity {
    public static LocationUtils mLocationUtils = null;

    private Button btn_choosecity;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        btn_choosecity = (Button) findViewById(R.id.btn_choosecity);
        btn_choosecity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddressActivity.class);
                MainActivity.this.startActivity(intent);
            }
        });
    }
}