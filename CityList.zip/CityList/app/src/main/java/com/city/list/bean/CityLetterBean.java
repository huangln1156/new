package com.city.list.bean;

import java.io.Serializable;

/**
 * Created by Administrator on 2018/5/14.
 */

public class CityLetterBean implements Serializable {
    private String letterName;
    private int height;

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }

    public String getLetterName() {
        return letterName;
    }

    public void setLetterName(String letterName) {
        this.letterName = letterName;
    }

    @Override
    public String toString() {
        return "CityLetterBean{" +
                "letterName='" + letterName + '\'' +
                ", height=" + height +
                '}';
    }
}
