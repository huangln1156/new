package com.city.list.utils;

import android.content.Context;
import android.content.res.AssetManager;

import com.city.list.bean.CityBean2;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.List;

/**
 * Created by Administrator on 2018/5/14.
 */

public class Utils {

    /**
     * 将数据转换成json 类型
     *
     * @param list
     * @return
     */
    public static String ProLogList2Json(List<CityBean2> list){
        JSONArray jsonarry= new JSONArray();
        for (int i=0;i<list.size();i++){
            JSONObject json = new JSONObject();
            try {
                json.put("initial", list.get(i).getInitial());
                JSONArray jsonarry2= new JSONArray();
                for (int j=0;j<list.get(i).getItems().size();j++){
                    JSONObject json2 = new JSONObject();
                    json2.put("initial", list.get(i).getInitial());
                    json2.put("area_code", list.get(i).getItems().get(j).getArea_code());
                    json2.put("city_name_name", list.get(i).getItems().get(j).getCity_name_name());
                    jsonarry2.put(json2);
                }
                json.put("list", jsonarry2);
                jsonarry.put(json);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }
        return jsonarry.toString();
    }




    /**
     * 获得assets json文件的城市
     * @param fileName json文件名字
     * @param context 上下文
     * @return
     */
    public static String getJson(String fileName,Context context) {
        //将json数据变成字符串
        StringBuilder stringBuilder = new StringBuilder();
        try {
            //获取assets资源管理器
            AssetManager assetManager = context.getAssets();
            //通过管理器打开文件并读取
            BufferedReader bf = new BufferedReader(new InputStreamReader(
                    assetManager.open(fileName)));
            String line;
            while ((line = bf.readLine()) != null) {
                stringBuilder.append(line);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return stringBuilder.toString();
    }
}
