package com.city.list;

import android.content.Context;
import android.graphics.Color;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.city.list.bean.CityBean;
import com.city.list.bean.CityBean2;
import com.city.list.bean.CityLetterBean;
import com.city.list.bean.ItemsBean;
import com.city.list.utils.LogUtil;
import com.city.list.utils.Utils;
import com.google.gson.Gson;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {
    private ArrayList<ItemsBean> listNew=new ArrayList<>();//排序之后的list  adapter中展示的数据
    private ArrayList<CityBean2> list2=new ArrayList<>();//排序之后的list  adapter中展示的数据
    private ArrayList<ItemsBean> listselect = new ArrayList<>();//搜索之后的list
    private ArrayList<CityLetterBean> letterList = new ArrayList<>();//右边字母的list
    private Context context;
    private String[] city={"A", "B", "C", "D", "E", "F", "G", "H","J", "K", "L", "M", "N", "P", "Q", "R", "S", "T", "W", "X", "Y", "Z"};

    private RecyclerView mRecyclerView;//主界面城市列表 里面包含个二级recyclerView
    private RecyclerView mRecyclerViewSelect;//主界面城市列表 里面包含个二级recyclerView
    private RecyclerView recyclerViewLetter;//右边字母recyclerView
    private BaseQuickAdapter<ItemsBean, BaseViewHolder> mAdapter;//主界面一级字母城市列表

    private BaseQuickAdapter<ItemsBean, BaseViewHolder> mSelectAdapter;//编辑框筛选的城市名字的adapter
    private BaseQuickAdapter<CityLetterBean, BaseViewHolder> mLetterAdapter;//最右面字母显示

    private EditText select;
    private Map<Integer,String> keys=new HashMap<>();//存放所有key的位置和内容

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        initData();
        initLetterData();
        initAdapter();
        selectCity();
        initLetterAdapter();
    }

    private void initLetterData() {

        WindowManager wm = this.getWindowManager();
        int height = wm.getDefaultDisplay().getHeight();

        for (int i = 0; i < city.length; i++) {
            CityLetterBean bean = new CityLetterBean();
            bean.setLetterName(city[i]);
            bean.setHeight(height/28);
            letterList.add(bean);
        }
    }

    private void initView() {
        context = this;
        recyclerViewLetter= (RecyclerView) findViewById(R.id.recyclerViewLetter);
        mRecyclerView = (RecyclerView) findViewById(R.id.recyclerView);
        mRecyclerViewSelect = (RecyclerView) findViewById(R.id.recyclerView2);
        select= (EditText) findViewById(R.id.select);
    }
    /**
     * 搜索框 搜索城市名字
     */
    private void selectCity() {

        select.addTextChangedListener(new TextWatcher() {
            public void afterTextChanged(Editable edt) {

                String temp = edt.toString();
                if(!TextUtils.isEmpty(temp)){
                    listselect.clear();
                   for (int i = 0; i < list2.size(); i++) {

                        for (int j = 0; j < list2.get(i).getItems().size(); j++){
                            if (list2.get(i).getItems().get(j).getCity_name_name().contains(temp)){

                                ItemsBean itembean = new ItemsBean();
                                itembean.setCity_name_name(list2.get(i).getItems().get(j).getCity_name_name());
                                itembean.setInitial(list2.get(i).getItems().get(j).getInitial());
                                itembean.setArea_code(list2.get(i).getItems().get(j).getArea_code());

                                listselect.add(itembean);

                            }

                        }

                    }
                    LogUtil.e("mListSelectBody:",listselect.toString());

                    initSelectAdapter();
                }else {
                    initAdapter();
                }

            }

            public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
            }

            public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
            }
        });

    }

    /**
     * 获取json文件中的数据  并将数据变成2级list json数据
     */
    private void initData() {
        ArrayList<CityBean> list=new ArrayList<>();//获取json数据放在list中
        String string = Utils.getJson("gongjijing.json", context);
        CityBean bean = new Gson().fromJson(string, CityBean.class);
        list.addAll(bean.getData());

        //把数据进行排序 按a b c d 的方式
        for (int i = 0; i < city.length; i++) {
            CityBean2 bean2 = new CityBean2();
            bean2.setInitial(city[i]);
            ArrayList<ItemsBean> list3 = new ArrayList<>();//最底层的城市 注意要重新new 一个list 不然会重复
            for (int j = 0; j < list.size(); j++) {
                if (list.get(j).getCity_initial().equals(city[i])) {
                    ItemsBean itembean = new ItemsBean();
                    itembean.setCity_name_name(list.get(j).getCity_name());
                    itembean.setInitial(list.get(j).getCity_initial());
                    itembean.setArea_code(list.get(j).getArea_code());
                    list3.add(itembean);
                }

                bean2.setItems(list3);
            }

            list2.add(bean2);
        }

        // String str = Utils.ProLogList2Json(list2);//把数据转成json


        for(int i=0;i<list2.size();i++){
            keys.put(listNew.size(),list2.get(i).getInitial());
            for (int j = 0; j < list2.get(i).getItems().size(); j++) {
                listNew.add( list2.get(i).getItems().get(j));
            }
        }


        LogUtil.e("listNew",listNew.toString());

    }



    private void initAdapter() {
        mRecyclerViewSelect.setVisibility(View.GONE);
        mRecyclerView.setVisibility(View.VISIBLE);
        final FloatingItemDecoration floatingItemDecoration=new FloatingItemDecoration(this, 0,1,1);
        floatingItemDecoration.setKeys(keys);
        floatingItemDecoration.setmTitleHeight((int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,50,getResources().getDisplayMetrics()));
        mRecyclerView.addItemDecoration(floatingItemDecoration);


        LinearLayoutManager layoutManager=new LinearLayoutManager(this);
        layoutManager.setOrientation(1);
        mRecyclerView.setLayoutManager(layoutManager);
        mRecyclerView.setHasFixedSize(true);

        mRecyclerView.setAdapter(mAdapter = new BaseQuickAdapter<ItemsBean, BaseViewHolder>(R.layout.list_item_main2, listNew) {
            @Override
            protected void convert(BaseViewHolder helper, final ItemsBean bean) {
                helper.setText(R.id.text2, bean.getCity_name_name());

            }
        });
        mAdapter.setEnableLoadMore(true);
        // 默认提供5种方法（渐显、缩放、从下到上，从左到右、从右到左）
        mAdapter.openLoadAnimation(BaseQuickAdapter.ALPHAIN);




    }



    public void initSelectAdapter(){


        keys.clear();
        mRecyclerViewSelect.setVisibility(View.VISIBLE);
        mRecyclerView.setVisibility(View.GONE);
        LinearLayoutManager layoutManager=new LinearLayoutManager(this);
        layoutManager.setOrientation(1);
        mRecyclerViewSelect.setLayoutManager(layoutManager);
        mRecyclerViewSelect.setHasFixedSize(true);

        mRecyclerViewSelect.setAdapter(mSelectAdapter = new BaseQuickAdapter<ItemsBean, BaseViewHolder>(R.layout.list_item_main2, listselect) {
            @Override
            protected void convert(BaseViewHolder helper, final ItemsBean bean) {
                helper.setText(R.id.text2, bean.getCity_name_name());

            }
        });
        mSelectAdapter.setEnableLoadMore(true);
        // 默认提供5种方法（渐显、缩放、从下到上，从左到右、从右到左）
        mSelectAdapter.openLoadAnimation(BaseQuickAdapter.ALPHAIN);
    }


    public void initLetterAdapter(){
        recyclerViewLetter.setLayoutManager(new LinearLayoutManager(this));
        recyclerViewLetter.setAdapter(mLetterAdapter = new BaseQuickAdapter<CityLetterBean, BaseViewHolder>(R.layout.list_item_letter, letterList) {
            @Override
            protected void convert(final BaseViewHolder helper, final CityLetterBean bean) {
               TextView letterText= helper.getView(R.id.text2);
                helper.setText(R.id.text2, bean.getLetterName());
                ViewGroup.LayoutParams p=  letterText.getLayoutParams();
                p.height = bean.getHeight();
                letterText.setLayoutParams(p);
                //点击字母到指定位子
                letterText.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        helper.getLayoutPosition();
                        int num=0;
                        for(int i=0;i<helper.getLayoutPosition();i++){


                            for(int j=0;j<list2.get(i).getItems().size();j++){
                                num++;//获得点击的位子并且跳转到相应位子
                            }
                        }
                        Toast.makeText(mContext, ""+bean.getLetterName(), Toast.LENGTH_SHORT).show();

                        ((LinearLayoutManager)mRecyclerView.getLayoutManager()).scrollToPositionWithOffset( num, 0);
                        ((LinearLayoutManager)mRecyclerView.getLayoutManager()).setStackFromEnd(true);
                    }
                });
            }
        });
        mLetterAdapter.setEnableLoadMore(true);
        // 默认提供5种方法（渐显、缩放、从下到上，从左到右、从右到左）
        mLetterAdapter.openLoadAnimation(BaseQuickAdapter.ALPHAIN);
    }
}
