package com.city.list.bean;

import java.io.Serializable;
import java.util.List;

/**
 * Created by Administrator on 2018/5/10.
 */

public class CityBean  implements Serializable{
    /*	"area_code": " 314400",
                "city_name": " 海宁",
                "city_initial": "H"*/

    private List<CityBean> data;
    private String area_code;
    private String city_name;
    private String city_initial;

    public List<CityBean> getData() {
        return data;
    }

    public void setData(List<CityBean> data) {
        this.data = data;
    }

    public String getArea_code() {
        return area_code;
    }

    public void setArea_code(String area_code) {
        this.area_code = area_code;
    }

    public String getCity_name() {
        return city_name;
    }

    public void setCity_name(String city_name) {
        this.city_name = city_name;
    }

    public String getCity_initial() {
        return city_initial;
    }

    public void setCity_initial(String city_initial) {
        this.city_initial = city_initial;
    }

    @Override
    public String toString() {
        return "CityBean{" +
                "data=" + data +
                ", area_code='" + area_code + '\'' +
                ", city_name='" + city_name + '\'' +
                ", city_initial='" + city_initial + '\'' +
                '}';
    }
}
