package com.city.list.bean;

import java.io.Serializable;
import java.util.List;

/**
 * Created by Administrator on 2018/5/10.
 */

public class CityBean2 implements Serializable {

    /**
     * initial : A
     * items : [{"area_code":"750306","city_name_name":"阿拉善盟","initial":"A"}]
     */

    private String initial;
    private List<ItemsBean> items;

    public String getInitial() {
        return initial;
    }

    public void setInitial(String initial) {
        this.initial = initial;
    }

    public List<ItemsBean> getItems() {
        return items;
    }

    public void setItems(List<ItemsBean> items) {
        this.items = items;
    }

    @Override
    public String toString() {
        return "CityBean2{" +
                "initial='" + initial + '\'' +
                ", items=" + items +
                '}';
    }
}
