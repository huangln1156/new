package com.city.list.bean;

import java.io.Serializable;

/**
 * Created by Administrator on 2018/5/10.
 */

public class ItemsBean implements Serializable {

    private String area_code;
    private String city_name_name;
    private String initial;

    public String getArea_code() {
        return area_code;
    }

    public void setArea_code(String area_code) {
        this.area_code = area_code;
    }

    public String getCity_name_name() {
        return city_name_name;
    }

    public void setCity_name_name(String city_name_name) {
        this.city_name_name = city_name_name;
    }

    public String getInitial() {
        return initial;
    }

    public void setInitial(String initial) {
        this.initial = initial;
    }


    @Override
    public String toString() {
        return "ItemsBean{" +
                "area_code='" + area_code + '\'' +
                ", city_name_name='" + city_name_name + '\'' +
                ", initial='" + initial + '\'' +
                '}';
    }
}
